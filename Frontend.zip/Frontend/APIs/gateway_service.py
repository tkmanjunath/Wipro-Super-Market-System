from flask import Flask, request, jsonify
from flask_cors import CORS
import requests

app = Flask(__name__)
CORS(app)

INVENTORY_SERVICE_URL = "http://127.0.0.1:5001"
SALES_SERVICE_URL = "http://127.0.0.1:5002"

# valid_users = {
#   "username": "admin",
#   "password": "admin@123"
# }

@app.route('/login', methods=['POST'])
def login():
    data = request.json
    username = data.get("username")
    password = data.get("password")
    if username == "admin" and password == "admin@123":
        return jsonify({"message": "Login successful"}), 200
    return jsonify({"message": "Invalid username or password"}), 401

@app.route('/inventory/products', methods=['GET', 'POST'])
@app.route('/inventory/products/<path:path>', methods=['GET', 'PUT', 'DELETE'])
def inventory_proxy(path=None):
    method = request.method
    url = f"{INVENTORY_SERVICE_URL}/products/{path}" if path else f"{INVENTORY_SERVICE_URL}/products"
   
    if method == "GET":
        resp = requests.get(url)
    elif method == "POST":
        resp = requests.post(url, json=request.json)
    elif method == "PUT":
        resp = requests.put(url, json=request.json)
    elif method == "DELETE":
        resp = requests.delete(url)
    else:
        return jsonify({"message": "Method not allowed"}), 405
    return (resp.content, resp.status_code, resp.headers.items())


@app.route('/sales/sales', methods=['GET', 'POST'])
@app.route('/sales/sales/<int:sale_id>', methods=['GET', 'PUT', 'DELETE'])
def sales_proxy(sale_id=None):
    method = request.method
    url = f"{SALES_SERVICE_URL}/sales/{sale_id}" if sale_id else f"{SALES_SERVICE_URL}/sales"
   
    if method == "GET":
        resp = requests.get(url)
    elif method == "POST":
        resp = requests.post(url, json=request.json)
    elif method == "PUT":
        resp = requests.put(url, json=request.json)
    elif method == "DELETE":
        resp = requests.delete(url)
    else:
        return jsonify({"message": "Method not allowed"}), 405
    return (resp.content, resp.status_code, resp.headers.items())

if __name__ == "__main__":
    app.run(port=5000)

