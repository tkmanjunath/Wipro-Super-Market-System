from flask import Flask, jsonify, request
from flask_cors import CORS

app = Flask(__name__)
CORS(app)
products = [
    {"id": 1, "category": "Electronics", "name": "smartwatches", "price": 100, "stock": 100},
    {"id": 2, "category": "Fashion & Apparel", "name": "shoes", "price": 15, "stock": 90},
    {"id": 3, "category": "Food & Grocery", "name": "snacks", "price": 45, "stock": 150},
    {"id": 4, "category": "Health & Wellness", "name": "fitness gear", "price": 39, "stock": 120},
    {"id": 5, "category": "Beauty & Cosmetics", "name": "grooming kits", "price": 42, "stock": 80},
    {"id": 6, "category": "Home & Furniture", "name": "Sofas", "price": 10, "stock": 50},
    {"id": 7, "category": "Baby & Kids", "name": "Toys", "price": 120, "stock": 70},
]

@app.route('/products', methods=['GET'])
def get_all_products():
    return jsonify(products)

@app.route('/products/<int:product_id>', methods=['GET'])
def get_product(product_id):
    product = next((p for p in products if p["id"] == product_id), None)
    if product:
        return jsonify(product)
    return jsonify({"message": "Product not found"}), 404

@app.route('/products', methods=['POST'])
def add_product():
    data = request.json
    new_product = {
        "id": max(p["id"] for p in products) + 1,
        "category": data.get("category"),
        "name": data.get("name"),
        "price": data.get("price"),
        "stock": data.get("stock"),
    }
    products.append(new_product)
    return jsonify(new_product), 201

@app.route('/products/<int:product_id>', methods=['PUT'])
def update_product(product_id):
    global products
    data = request.json
    # print(data)
    for idx, p in enumerate(products):
        if p["id"] == product_id:
            updated_product = {
                "id": product_id,
                "category": data.get("category", p["category"]),
                "name": data.get("name", p["name"]),
                "price": data.get("price", p["price"]),
                "stock": data.get("stock", p["stock"]),
            }
            products[idx] = updated_product
            # print(updated_product)
            return jsonify(updated_product)
    return jsonify({"message": "Product not found"}), 404

@app.route('/products/<int:product_id>', methods=['DELETE'])
def delete_product(product_id):
    global products
    products = [p for p in products if p["id"] != product_id]
    return jsonify({"message": "Product deleted"})

if __name__ == "__main__":
    app.run(port=5001)

