from flask import Flask, jsonify, request
from flask_cors import CORS
import requests
from datetime import datetime

app = Flask(__name__)
CORS(app)

sales = [
    {"id": 1, "quantity": 2, "stock": 98, "date": "2025-08-20", "tax": 0.2},
    {"id": 2, "quantity": 1, "stock": 89, "date": "2025-08-21", "tax": 0.1},
    {"id": 3, "quantity": 5, "stock": 145, "date": "2025-08-18", "tax": 0.5},
    {"id": 4, "quantity": 3, "stock": 117, "date": "2025-08-22", "tax": 0.3},
    {"id": 5, "quantity": 4, "stock": 76, "date": "2025-08-19", "tax": 0.4},
    {"id": 6, "quantity": 1, "stock": 49, "date": "2025-08-23", "tax": 0.1},
    {"id": 7, "quantity": 2, "stock": 68, "date": "2025-08-17", "tax": 0.2},
]

INVENTORY_SERVICE_URL = "http://127.0.0.1:5001"

@app.route('/sales', methods=['GET'])
def get_all_sales():
    return jsonify(sales)

@app.route('/sales/<int:sale_id>', methods=['GET'])
def get_sale(sale_id):
    sale = next((s for s in sales if s["id"] == sale_id), None)
    if sale:
        return jsonify(sale)
    return jsonify({"message": "Sale not found"}), 404

@app.route('/sales', methods=['POST'])
def add_sale():
    data = request.json
    product_id = data.get("product_id")
    quantity = data.get("quantity")
    tax = data.get("tax", 0)

    product_resp = requests.get(f"{INVENTORY_SERVICE_URL}/products/{product_id}")
    if product_resp.status_code != 200:
        return jsonify({"message": "Product not found"}), 404

    product = product_resp.json()
    if product["stock"] < quantity:
        return jsonify({"message": "Insufficient stock"}), 400

    new_stock = product["stock"] - quantity
    update_resp = requests.put(f"{INVENTORY_SERVICE_URL}/products/{product_id}", json={
        "stock": new_stock
    })
    if update_resp.status_code != 200:
        return jsonify({"message": "Failed to update stock"}), 500

    new_sale = {
        "id": max(s["id"] for s in sales) + 1 if sales else 1,
        "quantity": quantity,
        "stock": new_stock,
        "date": datetime.now().strftime("%Y-%m-%d"),
        "tax": tax,
    }
    sales.append(new_sale)
    return jsonify(new_sale), 201

@app.route('/sales/<int:sale_id>', methods=['PUT'])
def update_sale(sale_id):
    data = request.json
    sale = next((s for s in sales if s["id"] == sale_id), None)
    if not sale:
        return jsonify({"message": "Sale not found"}), 404

    quantity = data.get("quantity", sale["quantity"])
    tax = data.get("tax", sale["tax"])

    sale.update({
        "quantity": quantity,
        "tax": tax,
        "date": datetime.now().strftime("%Y-%m-%d"),  
    })
    return jsonify(sale)

@app.route('/sales/<int:sale_id>', methods=['DELETE'])
def delete_sale(sale_id):
    global sales
    sale = next((s for s in sales if s["id"] == sale_id), None)
    if not sale:
        return jsonify({"message": "Sale not found"}), 404
    sales = [s for s in sales if s["id"] != sale_id]
    return jsonify({"message": "Sale deleted"})

if __name__ == "__main__":
    app.run(port=5002)

