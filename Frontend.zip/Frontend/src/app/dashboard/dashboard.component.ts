import { Component } from '@angular/core';
import { SidebarComponent } from '../sidebar/sidebar.component'; // adjust path as needed
import { HeaderComponent } from '../header/header.component';
import { FooterComponent } from '../footer/footer.component';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [SidebarComponent,HeaderComponent,FooterComponent,CommonModule,FormsModule],  // <-- include here
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent {
  Productfilter: string = 'RECENT SELLING';
}
