import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { NgxSpinnerService } from 'ngx-spinner';
import { CommonModule } from '@angular/common';
import { LoaderComponent } from '../loader/loader.component';
import { LoginService } from '../services/login.service';
@Component({
  selector: 'app-login',
  standalone: true,
  imports: [RouterModule, FormsModule, CommonModule, LoaderComponent],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  userName: string = '';
  password: string = '';
  constructor(private router: Router, public toastr: ToastrService, public spinner: NgxSpinnerService, public loginService: LoginService) {
  }
  isEmpty(val: any) {
    return (val === 0 || val === '0' || val === false || val === '' || val === undefined || val == null || val.length <= 0) ? true : false;
  }
  errorMsg(msg: any) {
    let vm = this;
    vm.toastr.error(msg, 'Error')
  }
  userLogin() {
    let vm = this;
    if (vm.isEmpty(vm.userName)) {
      vm.errorMsg('Please your user name!');
    } else if (vm.isEmpty(vm.password)) {
      vm.errorMsg('Please your password!');
    } else {
      let body = {
        "username": vm.userName,
        "password": vm.password
      }
      let payLoad = JSON.stringify(body);
      vm.loginService.loginRequest(payLoad).subscribe({
        next: (data: any) => {
          vm.spinner.hide();
          //console.log(data);
          if (data.message === 'Login successful') {
            vm.toastr.success(data.message, 'Success');
            this.router.navigate(['/dashboard']);
          }
          else {
            vm.errorMsg(data.message)
          }
        },
        error: (err: any) => {
          vm.spinner.hide();
          vm.errorMsg('Login failed. Please try again.');
        }
      });
    }
  }
}
