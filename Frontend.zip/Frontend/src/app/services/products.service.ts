import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { catchError, map } from 'rxjs/operators';
import { throwError } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class ProductsService {
  private apiUrl = 'http://127.0.0.1:5001';
  constructor(public _httpClient: HttpClient) { }
  getProducts() {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });
    return this._httpClient.get(this.apiUrl + '/products', { headers })
      .pipe(
        map((data: any) => {
          return data;
        }),
        catchError(this.handleError)
      );
  }

  addProduct(payLoad: any) {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });
    return this._httpClient.post(this.apiUrl + '/products', payLoad, { headers })
      .pipe(
        map((data: any) => {
          return data;
        }),
        catchError(this.handleError)
      );
  }

  updateProduct(prodcutId: any, payLoad: any) {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });
    return this._httpClient.put(this.apiUrl + '/products' + '/' + prodcutId, payLoad, { headers })
      .pipe(
        map((data: any) => {
          return data;
        }),
        catchError(this.handleError)
      );
  }

  deleteProduct(prodcutId: any) {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });
    return this._httpClient.delete(this.apiUrl + '/products' + '/' + prodcutId, { headers })
      .pipe(
        map((data: any) => {
          return data;
        }),
        catchError(this.handleError)
      );
  }

  private handleError(error: any) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      errorMessage = `Error: ${error.error.message}`;
    } else {
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    console.error(errorMessage); // Log the error for debugging
    return throwError(() => new Error(errorMessage)); // Provide a more informative error
  }
}
