import { Component } from '@angular/core';
import { SidebarComponent } from '../sidebar/sidebar.component'; // adjust path as needed
import { HeaderComponent } from '../header/header.component';
import { FooterComponent } from '../footer/footer.component';
import { CommonModule } from '@angular/common';
import { FormsModule, NgForm } from '@angular/forms';
declare var bootstrap: any;
@Component({
  selector: 'app-users',
  standalone: true,
  imports: [
    SidebarComponent,
    HeaderComponent,
    FooterComponent,
    CommonModule,
    FormsModule,
  ], // <-- include here
  templateUrl: './users.component.html',
  styleUrl: './users.component.css',
})
export class UsersComponent {
  users = [
    {
      name: 'John Doe',
      email: 'john@example.com',
      role: 'Admin',
      status: 'Active',
    },
    {
      name: 'Jane Smith',
      email: 'jane@example.com',
      role: 'User',
      status: 'Pending',
    },
  ];

  selectedUser: any = {};

  // Open modal with user data
  editUser(user: any) {
    this.selectedUser = { ...user }; // clone object
    const modal = new bootstrap.Modal(
      document.getElementById('editUserModal')!
    );
    modal.show();
  }

  // Submit edited data
  onEditSubmit(form: any) {
    if (form.valid) {
      // Find original user and update
      const index = this.users.findIndex(
        (u) => u.email === this.selectedUser.email
      );
      if (index !== -1) this.users[index] = { ...this.selectedUser };

      // Close modal
      const modalEl = document.getElementById('editUserModal')!;
      const modal = bootstrap.Modal.getInstance(modalEl);
      modal?.hide();
    }
  }

  onSubmit(form: NgForm) {
    if (form.valid) {
      this.users.push(form.value);
      form.reset();

      // Close modal programmatically
      const modalElement = document.getElementById('addUserModal');
      const modal = new bootstrap.Modal(modalElement!);
      modal.hide();
    }
  }

  blockUser(user: any) {
    user.status = user.status === 'Blocked' ? 'Active' : 'Blocked';
  }

  deleteUser(user: any) {
    this.users = this.users.filter((u) => u !== user);
  }
}
