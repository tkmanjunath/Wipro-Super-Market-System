import { Component } from '@angular/core';
import { SidebarComponent } from '../sidebar/sidebar.component'; // adjust path as needed
import { HeaderComponent } from '../header/header.component';
import { FooterComponent } from '../footer/footer.component';
import { CommonModule } from '@angular/common';
import { FormsModule, NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ProductsService } from '../services/products.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { LoaderComponent } from '../loader/loader.component';
declare var bootstrap: any;
@Component({
  selector: 'app-products',
  standalone: true,
  imports: [SidebarComponent, HeaderComponent, FooterComponent, CommonModule, FormsModule, LoaderComponent],  // <-- include here
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent {
  products: any[] = [];
  categories: any[] = [];
  productName: string = '';
  category: string = '';
  price: number = 0;
  stock: number = 0;
  editProductId: any = null;
  constructor(private router: Router, public toastr: ToastrService, public productService: ProductsService, public spinner: NgxSpinnerService) {
    let vm = this;
    vm.loadProducts();
  }
  loadProducts() {
    let vm = this;
    vm.spinner.show();
    vm.productService.getProducts().subscribe({
      next: (data: any) => {
        vm.spinner.hide();
        //console.log(data);
        vm.products = data;
        vm.categories = [...new Set(data.map((item: any) => item.category))];
        console.log(vm.categories);
      },
      error: (err: any) => {
        vm.spinner.hide();
        vm.errorMsg('Get products apis call failed. Please try again.');
      }
    });
  }
  errorMsg(msg: any) {
    let vm = this;
    vm.toastr.error(msg, 'Error')
  }
  // products = [
  //   { name: 'Apple', category: 'Fruits', Price: 280, stock: 120 },
  //   { name: 'Banana', category: 'Fruits', Price: 80, stock: 0 },
  //   { name: 'Milk', category: 'Dairy', Price: 50, stock: 300 },
  //   { name: 'Bread', category: 'Bakery', Price: 60, stock: 20 },
  // ];

  // newProduct = { name: '', category: '', Price: 0, stock: 0 };
  editProduct(product: any): void {
    let vm = this;
    // Clear the form
    vm.resetForm();
    vm.productName = product.name;
    vm.category = product.category;
    vm.price = product.price;
    vm.stock = product.stock;
    vm.editProductId = product.id;
    const modalElement = document.getElementById('editProductModal');
    if (modalElement) {
      let modalInstance = bootstrap.Modal.getInstance(modalElement);
      if (!modalInstance) {
        modalInstance = new bootstrap.Modal(modalElement);
      }
      // Ensure modalInstance is initialized before calling show()
      if (modalInstance) {
        modalInstance.show();
      }

    }
  }

  updateProduct() {
    let vm = this;
    if (vm.isEmpty(vm.productName)) {
      vm.errorMsg('Please enter the product name!');
    } else if (vm.isEmpty(vm.category)) {
      vm.errorMsg('Please choose a category!');
    } else if (vm.isEmpty(vm.price) || vm.price <= 0) {
      vm.errorMsg('Please enter valid price!');
    } else if (vm.isEmpty(vm.stock) || vm.stock < 0) {
      vm.errorMsg('Please enter valid stock!');
    } else {
      // Call the API to update the product
      let body = {
        "category": vm.category,
        "name": vm.productName,
        "price": vm.price,
        "stock": vm.stock
      }
      let payLoad = JSON.stringify(body);
      vm.spinner.show();
      vm.productService.updateProduct(vm.editProductId, payLoad).subscribe({
        next: (data: any) => {
          vm.spinner.hide();
          // Clear the form
          vm.resetForm();
          // Close the modal
          const modalElement = document.getElementById('editProductModal');
          if (modalElement) {
            const modalInstance = bootstrap.Modal.getInstance(modalElement);
            if (modalInstance) {
              modalInstance.hide();
              this.loadProducts(); // Refresh the product list
            }
          }
        },
        error: (err: any) => {
          vm.spinner.hide();
          vm.errorMsg('Update product API call failed. Please try again.');
        }
      });
    }
  }

  deleteProduct(product: any) {
    //this.products = this.products.filter((p) => p !== product);
    let vm = this;
    vm.spinner.show();
    vm.productService.deleteProduct(product.id).subscribe({
      next: (data: any) => {
        vm.spinner.hide();
        vm.loadProducts(); // Refresh the product list
      },
      error: (err: any) => {
        vm.spinner.hide();
        vm.errorMsg('Delete product API call failed. Please try again.');
      }
    });
  }

  openAddProductModal() {
    let vm = this;
    vm.resetForm();
    const modalElement = document.getElementById('addProductModal');
    if (modalElement) {
      let modalInstance = bootstrap.Modal.getInstance(modalElement);
      if (!modalInstance) {
        modalInstance = new bootstrap.Modal(modalElement);
      }
      // Ensure modalInstance is initialized before calling show()
      if (modalInstance) {
        modalInstance.show();
      }
    }
  }

  addProduct() {
    let vm = this;
    if (vm.isEmpty(vm.productName)) {
      vm.errorMsg('Please enter the product name!');
    } else if (vm.isEmpty(vm.category)) {
      vm.errorMsg('Please choose a category!');
    } else if (vm.isEmpty(vm.price) || vm.price <= 0) {
      vm.errorMsg('Please enter valid price!');
    } else if (vm.isEmpty(vm.stock) || vm.stock < 0) {
      vm.errorMsg('Please enter valid stock!');
    } else {
      // Call the API to add the product
      let body = {
        "category": vm.category,
        "name": vm.productName,
        "price": vm.price,
        "stock": vm.stock
      }
      let payLoad = JSON.stringify(body);
      vm.spinner.show();
      vm.productService.addProduct(payLoad).subscribe({
        next: (data: any) => {
          vm.spinner.hide();
          // Clear the form
          vm.resetForm();
          // Close the modal
          const modalElement = document.getElementById('addProductModal');
          if (modalElement) {
            const modalInstance = bootstrap.Modal.getInstance(modalElement);
            if (modalInstance) {
              modalInstance.hide();
              this.loadProducts(); // Refresh the product list
            }
          }
        },
        error: (err: any) => {
          vm.spinner.hide();
          vm.errorMsg('Add product API call failed. Please try again.');
        }
      });
    }
  }
  resetForm() {
    let vm = this
    vm.productName = '';
    vm.category = '';
    vm.price = 0;
    vm.stock = 0;
    vm.editProductId = null;
  }
  isEmpty(val: any) {
    return (
      val === 0 ||
      val === '0' ||
      val === false ||
      val === '' ||
      val === undefined ||
      val == null ||
      (typeof val === 'string' || Array.isArray(val) ? val.length <= 0 : false)
    ) ? true : false;
  }

}
