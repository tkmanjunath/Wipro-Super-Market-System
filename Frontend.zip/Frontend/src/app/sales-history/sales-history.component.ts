import { Component } from '@angular/core';
import { SidebarComponent } from '../sidebar/sidebar.component'; // adjust path as needed
import { HeaderComponent } from '../header/header.component';
import { FooterComponent } from '../footer/footer.component';
import { CommonModule } from '@angular/common';
@Component({
  selector: 'app-sales-history',
  standalone: true,
  imports: [SidebarComponent,HeaderComponent,FooterComponent,CommonModule],
  templateUrl: './sales-history.component.html',
  styleUrl: './sales-history.component.css'
})
export class SalesHistoryComponent {

}
