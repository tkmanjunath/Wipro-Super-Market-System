import { Component } from '@angular/core';
import { SidebarComponent } from '../sidebar/sidebar.component'; // adjust path as needed
import { HeaderComponent } from '../header/header.component';
import { FooterComponent } from '../footer/footer.component';
import { CommonModule } from '@angular/common';
@Component({
  selector: 'app-sales',
  standalone: true,
  imports: [SidebarComponent,HeaderComponent,FooterComponent,CommonModule],  // <-- include here
  templateUrl: './sales.component.html',
  styleUrl: './sales.component.css'
})
export class SalesComponent {
  products = [
    { id: 1, name: 'Product 1', category: 'Category A', price: 100, stock: 20, qty: 1 },
    { id: 2, name: 'Product 2', category: 'Category B', price: 150, stock: 10, qty: 1 },
    { id: 3, name: 'Product 3', category: 'Category A', price: 200, stock: 5, qty: 1 },
    { id: 4, name: 'Product 4', category: 'Category C', price: 250, stock: 0, qty: 1 },
  ];

  cart: any[] = [];

  increaseQty(product: any) {
    if (product.qty < product.stock) product.qty++;
  }

  decreaseQty(product: any) {
    if (product.qty > 1) product.qty--;
  }

  addToCart(product: any) {
    if (product.stock === 0) return;

    const exist = this.cart.find(p => p.id === product.id);
    if (exist) {
      exist.qty += product.qty;
      if (exist.qty > product.stock) exist.qty = product.stock;
    } else {
      this.cart.push({ ...product });
    }
    product.qty = 1;
  }

  removeFromCart(index: number) {
  this.cart.splice(index, 1);
}

  clearCart() {
    this.cart = [];
  }

  checkout() {
    console.log('Checkout cart:', this.cart);
    alert('Proceeding to checkout');
  }

  getTotal() {
    return this.cart.reduce((sum, item) => sum + item.price * item.qty, 0);
  }
}
